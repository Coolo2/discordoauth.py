

class MissingScope(Exception):
    pass

class MissingArgument(Exception):
    pass

class HTTPError(Exception):
    pass

from discordoauth import client, scopes

Client = client.Client
Scopes = scopes.Scopes
Object = client.Object
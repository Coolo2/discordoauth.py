
__version__ = "0.1.1"

from discordoauth import client, scopes

Client = client.Client
Scopes = scopes.Scopes
Object = client.Object
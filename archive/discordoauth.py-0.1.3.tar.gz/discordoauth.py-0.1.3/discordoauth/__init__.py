
__version__ = "0.1.3"

from discordoauth import client, scopes as oauth_scopes

Client = client.Client
Scopes = oauth_scopes.Scopes
Object = client.Object